<?php 
	include "../includes/finance_db_connect.php";
	include "../includes/session.php";
	include "update_expense.php";
		
	$admin_id = $_SESSION['email'];

	if(!isset($admin_id)){
	   header('location:../login.php');
	}

	if (!isset($_SESSION["passCode"])) {
	    header('location: tax_db.php');
	    exit;
	}

	// Unset only the 'passCode' session variable
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Admin</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "expenses.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<div class="back">
				<a href="expenses_db.php"><i class="fa-solid fa-arrow-right-arrow-left"></i></a>
			</div>
			 <form id="expenseForm" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
		      <h1 class="expense">Barangay Expense Management System</h1>

		      <label for="newExpense">Expense Type</label>
		      <input type="text" id="newExpense" name="newExpense" placeholder="Expense Type" value="<?php echo $results["type"] ?>">

		      <span class="errors">
				<?php echo $errors["expenses"]; ?>
			  </span>

		      <label for="amount">Amount</label>
		      <input type="number" id="amount" name="amount" placeholder="Amount" value="<?php echo $results["amount"] ?>">

		      <span class="errors">
				<?php echo $errors["amount"]; ?>
			  </span>

		      <label for="description">Particulars</label>
		      <textarea id="description" name="description" placeholder="Description" value="<?php echo $results["particulars"] ?>"></textarea>

		      <span class="errors">
				<?php echo $errors["desc"]; ?>
			  </span>

		      <button class="btn" type="submit" name="update">Add Expense</button>
		    </form>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
	<script type="text/javascript">
	// Tax Calculations
	function calculateTax() {
	  const propertyValue = parseFloat(document.getElementById('propertyValue').value);
	  const propertyType = document.getElementById('propertyType').value;
	  const location = document.getElementById('location').value;

	  const assessmentLevels = {
	    'Residential': {'City': 20, 'Municipality': 20, 'Province': 20},
	    'Commercial': {'City': 50, 'Municipality': 50, 'Province': 50},
	    'Agricultural': {'City': 40, 'Municipality': 40, 'Province': 40},
	    'Industrial': {'City': 50, 'Municipality': 50, 'Province': 50}
	  };

	  const taxRates = {'City': 0.02, 'Municipality': 0.02, 'Province': 0.01};
	  const sefRate = 0.01; // SEF rate is 1%

	  const assessmentLevel = assessmentLevels[propertyType][location];
	  const assessedValue = propertyValue * (assessmentLevel / 100);
	  const taxRate = taxRates[location];
	  const basicTax = assessedValue * taxRate;
	  const sefAmount = assessedValue * sefRate;
	  const totalTax = basicTax + sefAmount;

	  document.getElementById('assessedValue').value = assessedValue.toFixed(2);
	  document.getElementById('basicTax').value = basicTax.toFixed(2);
	  document.getElementById('sef').value = sefAmount.toFixed(2);
	  document.getElementById('totalTax').value = totalTax.toFixed(2);
	}

	</script>
</body>
</html>



	