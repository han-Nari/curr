<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "pass.php";

	$admin_id = $_SESSION['email'];

	if (!isset($admin_id)) {
	    header('location:../login.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Database</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "main.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section class="dbase">
			<?php if (!$formSubmitted): ?>
			 <form class="password" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
			 	<h1 class="whitey">Enter Your Password</h1>
				<div class="box">
					<i class="fa-solid fa-lock"></i>
					<input type="password" name="password" id="show" placeholder="Password">
				</div>
				<span class="errors">
					<?php echo $error["passCode"]; ?>
				</span>
			
				<input class="btn" type="submit" name="submit" value="Submit">
			</form>
			<?php endif; ?>
			<div class="db">
				<a class="rpt" href="rpt_db.php">Real Property Tax</a>


				<a class="finance" style="color: #000;" href="finance_db.php">Financial Management</a>
			</div>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	