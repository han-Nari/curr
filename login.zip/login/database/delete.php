<?php 

	if(isset($_POST["delete"])) {
		$id = htmlspecialchars($_POST["delete"]);

		try {
			$query = "DELETE FROM tax WHERE id = :id";
			$stmt = $pdo->prepare($query);
			$stmt->bindParam(":id", $id);
			$stmt->execute();
			
			if($stmt) {
				$_SESSION["delete"] = "Delete Successful!";
				header("location: tax_db.php");
			} 
			die();
		} catch (Exception $e) {
			die("Error" . $e->getMessage());
		}
	}
