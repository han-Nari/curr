<?php 
   $errors = array("error" => "");
   if($_SERVER["REQUEST_METHOD"] == "POST"){

     try {
          function dataInput($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
          }

          $email = dataInput($_POST['email']);
          $password = dataInput($_POST['password']);

          $query = $pdo->prepare("SELECT * FROM admins WHERE email = :email");
          $query->bindParam(":email", $email, PDO::PARAM_STR);
          $query->execute();
          $result = $query->fetch(PDO::FETCH_ASSOC);
          if(!$result) {
            echo "Form is empty";
          } else {
              if(password_verify($password, $result["password"])) {
                  $_SESSION["email"] = $result["id"];
                  header('location:dashboard/dash.php');
                  exit();
              } else {
                  $errors["error"] = "incorrect email or password!";
                }
        }
     } catch(PDOException $e) {
          die("Connection failed" . $e->getMessage());
       }
   }  
